# 动态逐帧检测系统 v2.0

## Enhanced Dynamic Frame-by-Frame Detection System

基于机器学习的智能结节检测与分析平台，专门用于处理时序应力数据，实现结节的自动检测、跟踪和分析。

![系统架构](https://img.shields.io/badge/Python-3.8+-blue.svg)
![依赖](https://img.shields.io/badge/Dependencies-NumPy%20%7C%20Pandas%20%7C%20Matplotlib-green.svg)
![版本](https://img.shields.io/badge/Version-2.0-red.svg)

## 🚀 主要功能

### 🔍 高精度结节检测
- **高斯混合模型算法**: 基于GMM的智能检测，支持2-5个组件的自适应分析
- **形态学后处理**: 包括开运算、闭运算、空洞填充等优化技术
- **多阈值检测**: 可调节的敏感度参数，适应不同数据特征
- **连通域分析**: 自动筛选有效结节，排除噪声干扰

### 📊 实时动态可视化
- **多视图显示**: 热力图、等高线图、3D表面图同步显示
- **实时播放控制**: 支持播放/暂停、帧跳转、速度调节
- **结节标记**: 实时显示检测结果，包括位置、大小、风险评分
- **参数实时调整**: 所见即所得的参数调节界面

### 📈 智能统计分析
- **趋势分析**: 线性回归、平滑滤波、显著性检验
- **异常检测**: Z-score统计法、Isolation Forest机器学习法
- **周期性分析**: 峰值检测、间隔分析、规律性评估
- **相关性分析**: 特征间相关性矩阵、强相关性识别

### 📋 多格式导出
- **GIF动画**: 高质量动态可视化，支持自定义帧率和分辨率
- **分析报告**: 详细的文本格式统计报告
- **Excel数据**: 完整的数据表格，包含所有检测结果
- **统计图表**: PNG格式的专业统计图表

## 📦 系统架构

```
动态逐帧检测系统/
├── main_detection_app.py          # 主应用程序入口
├── enhanced_detection_system.py   # 核心检测算法
├── modern_detection_gui.py        # 现代化GUI界面
├── statistical_analysis.py        # 统计分析模块
├── algorithms.py                  # 原始算法（兼容性）
└── README.md                      # 系统文档
```

### 核心模块说明

#### 1. EnhancedNoduleDetectionSystem
- **功能**: 核心检测算法实现
- **特点**: 高精度、多参数、可扩展
- **输入**: CSV格式应力数据（96个测点）
- **输出**: 结节位置、特征、风险评分

#### 2. ModernDetectionGUI
- **功能**: 现代化用户界面
- **特点**: 多选项卡、实时预览、参数调节
- **技术**: Tkinter + Matplotlib集成

#### 3. StatisticalAnalyzer
- **功能**: 统计分析和报告生成
- **特点**: 多维度分析、异常检测、趋势预测
- **算法**: 线性回归、机器学习、信号处理

## 🛠️ 安装和配置

### 系统要求
- **操作系统**: Windows 10/11, macOS 10.14+, Linux Ubuntu 18.04+
- **Python版本**: 3.8 或更高版本
- **内存**: 建议 8GB 以上
- **存储**: 至少 1GB 可用空间

### 依赖安装

```bash
# 核心科学计算库
pip install numpy pandas matplotlib scipy

# 机器学习库
pip install scikit-learn scikit-image

# 图像处理库
pip install Pillow

# 数据可视化增强
pip install seaborn

# 进度条显示
pip install tqdm

# Excel支持
pip install openpyxl
```

### 快速安装（推荐）

```bash
# 创建虚拟环境
python -m venv detection_env

# 激活虚拟环境
# Windows:
detection_env\Scripts\activate
# macOS/Linux:
source detection_env/bin/activate

# 安装所有依赖
pip install numpy pandas matplotlib scipy scikit-learn scikit-image Pillow seaborn tqdm openpyxl
```

## 🚀 使用指南

### 1. 启动系统

```bash
python main_detection_app.py
```

### 2. 数据准备

**CSV文件格式要求**:
- 必须包含 `MAT_0` 到 `MAT_95` 列（96个应力测点）
- 必须包含 `SN` 列作为时间戳
- 数据应为数值型，允许少量NaN值

**示例数据格式**:
```csv
SN,MAT_0,MAT_1,MAT_2,...,MAT_95
0.000,1.23,2.45,3.67,...,4.89
0.001,1.24,2.46,3.68,...,4.90
...
```

### 3. 基本操作流程

#### 步骤1: 加载数据
1. 点击"选择CSV文件"按钮
2. 选择符合格式要求的数据文件
3. 系统自动验证数据格式

#### 步骤2: 参数调整
- **GMM组件数**: 控制检测精度，建议2-4
- **平滑参数**: 控制噪声抑制，建议0.5-1.5
- **敏感度阈值**: 控制检测敏感度，建议0.5-0.8
- **最小结节面积**: 过滤小噪声，建议2-5

#### 步骤3: 实时分析
- 使用播放控制按钮浏览数据
- 观察实时检测结果
- 查看统计信息和趋势图

#### 步骤4: 结果导出
- **GIF动画**: 完整的动态可视化
- **分析报告**: 详细的统计分析
- **Excel数据**: 原始检测数据

### 4. 高级功能

#### 批量处理
```python
# 使用批量分析功能处理多个文件
# 1. 选择多个CSV文件
# 2. 指定输出目录
# 3. 系统自动处理所有文件
```

#### 自定义参数配置
```json
{
  "gmm_components": 3,
  "smoothing_sigma": 0.8,
  "sensitivity_threshold": 0.7,
  "min_nodule_area": 3,
  "play_speed": 500
}
```

## 📊 技术细节

### 检测算法原理

#### 1. 数据预处理
```python
# 缺失值处理
col_mean = np.nanmean(data, axis=0)
data[np.isnan(data)] = col_mean

# 高斯平滑
smoothed = gaussian_filter(data, sigma=0.8)

# 归一化
normalized = (data - data.min()) / (data.max() - data.min())
```

#### 2. 结节检测
```python
# 高斯混合模型
gmm = GaussianMixture(n_components=3, covariance_type='full')
labels = gmm.fit_predict(data.reshape(-1, 1))

# 异常类别识别
abnormal_class = np.argmax(gmm.means_)
nodule_mask = (labels.reshape(12, 8) == abnormal_class)
```

#### 3. 形态学后处理
```python
# 闭运算去噪
nodule_mask = closing(nodule_mask, disk(2))

# 开运算分离
nodule_mask = opening(nodule_mask, disk(1))

# 空洞填充
nodule_mask = binary_fill_holes(nodule_mask)
```

#### 4. 特征提取
```python
# 连通域分析
labeled = label(nodule_mask)
props = regionprops(labeled, intensity_image=normalized)

# 特征计算
for prop in props:
    area = prop.area
    circularity = 4 * π * area / (perimeter² )
    risk_score = calculate_risk(area, circularity, intensity)
```

### 统计分析算法

#### 1. 趋势分析
```python
# 线性回归
slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)

# Savitzky-Golay平滑
smoothed = savgol_filter(data, window_length=11, polyorder=3)
```

#### 2. 异常检测
```python
# Z-score方法
z_scores = np.abs((data - mean) / std)
anomalies = np.where(z_scores > threshold)[0]

# Isolation Forest
iso_forest = IsolationForest(contamination=0.1)
anomaly_labels = iso_forest.fit_predict(features)
```

## 🔧 配置和优化

### 性能优化建议

#### 1. 内存优化
- 限制最大处理帧数（建议≤100帧）
- 使用数据分块处理大文件
- 及时释放不需要的变量

#### 2. 计算优化
- 启用多线程处理（已默认开启）
- 使用GPU加速（需要CUDA支持）
- 调整图像分辨率以平衡质量和速度

#### 3. 参数调优
```python
# 针对不同数据类型的推荐参数
data_types = {
    "高噪声数据": {
        "smoothing_sigma": 1.2,
        "sensitivity_threshold": 0.8,
        "min_nodule_area": 5
    },
    "低噪声数据": {
        "smoothing_sigma": 0.5,
        "sensitivity_threshold": 0.6,
        "min_nodule_area": 2
    },
    "稀疏数据": {
        "gmm_components": 2,
        "sensitivity_threshold": 0.5
    }
}
```

## 📈 应用案例

### 案例1: 医学影像分析
- **应用场景**: CT扫描结节检测
- **数据特点**: 高分辨率、低噪声
- **推荐参数**: GMM=3, 平滑=0.6, 敏感度=0.7

### 案例2: 材料缺陷检测
- **应用场景**: 金属材料应力分析
- **数据特点**: 中等噪声、周期性变化
- **推荐参数**: GMM=4, 平滑=0.8, 敏感度=0.6

### 案例3: 地质勘探数据
- **应用场景**: 地下结构异常检测
- **数据特点**: 高噪声、不规则分布
- **推荐参数**: GMM=2, 平滑=1.2, 敏感度=0.8

## 🐛 故障排除

### 常见问题及解决方案

#### 1. 导入错误
```
ImportError: No module named 'xxx'
```
**解决方案**: 安装缺失的依赖包
```bash
pip install xxx
```

#### 2. 内存不足
```
MemoryError: Unable to allocate array
```
**解决方案**: 
- 减少处理帧数
- 降低图像分辨率
- 增加系统内存

#### 3. 检测效果不佳
**可能原因**:
- 参数设置不当
- 数据质量问题
- 算法不适合当前数据类型

**解决方案**:
- 调整检测参数
- 检查数据完整性
- 尝试不同的算法组合

#### 4. GUI无法启动
**可能原因**:
- Tkinter未正确安装
- 显示驱动问题
- 权限不足

**解决方案**:
```bash
# 重新安装Tkinter
sudo apt-get install python3-tk  # Linux
brew install python-tk           # macOS
```

## 📚 API参考

### EnhancedNoduleDetectionSystem

#### 主要方法

```python
class EnhancedNoduleDetectionSystem:
    def __init__(self):
        """初始化检测系统"""
        
    def advanced_nodule_detection(self, stress_grid, timestamp):
        """
        高级结节检测
        
        参数:
            stress_grid: 12x8的应力数据矩阵
            timestamp: 时间戳
            
        返回:
            normalized: 归一化后的数据
            nodule_mask: 结节掩码
            nodules: 检测到的结节列表
            prob_map: 概率图
        """
        
    def create_enhanced_visualization(self, df, output_path, max_frames=50):
        """
        创建增强版可视化
        
        参数:
            df: 包含应力数据的DataFrame
            output_path: 输出GIF路径
            max_frames: 最大处理帧数
            
        返回:
            bool: 是否成功生成
        """
```

### StatisticalAnalyzer

#### 主要方法

```python
class StatisticalAnalyzer:
    def analyze_nodule_trends(self, nodule_history):
        """分析结节特征变化趋势"""
        
    def generate_comprehensive_report(self):
        """生成综合分析报告"""
        
    def create_statistical_plots(self, save_path=None):
        """创建统计分析图表"""
        
    def export_detailed_data(self, save_path):
        """导出详细分析数据"""
```

## 🤝 贡献指南

### 开发环境设置

```bash
# 克隆项目
git clone https://github.com/your-repo/detection-system.git

# 创建开发环境
python -m venv dev_env
source dev_env/bin/activate  # Linux/macOS
dev_env\Scripts\activate     # Windows

# 安装开发依赖
pip install -r requirements-dev.txt
```

### 代码规范

- 遵循PEP 8编码规范
- 使用类型提示（Type Hints）
- 编写完整的文档字符串
- 添加单元测试

### 提交流程

1. Fork项目到个人仓库
2. 创建功能分支
3. 编写代码和测试
4. 提交Pull Request

## 📄 许可证

本项目采用MIT许可证，详见[LICENSE](LICENSE)文件。

## 📞 联系方式

- **项目维护者**: AI Assistant
- **技术支持**: 通过GitHub Issues提交问题
- **文档更新**: 欢迎提交文档改进建议

## 🔄 更新日志

### v2.0 (当前版本)
- ✨ 全新的现代化GUI界面
- 🚀 增强的检测算法性能
- 📊 完整的统计分析功能
- 🎬 高质量GIF动画导出
- 📋 详细的分析报告生成

### v1.0
- 🔍 基础结节检测功能
- 📊 简单的可视化界面
- 📁 CSV数据导入支持

## 🙏 致谢

感谢以下开源项目的支持：
- NumPy & SciPy: 科学计算基础
- Matplotlib: 数据可视化
- Scikit-learn: 机器学习算法
- Pandas: 数据处理
- Tkinter: GUI框架

---

**动态逐帧检测系统 v2.0** - 让结节检测更智能、更高效！