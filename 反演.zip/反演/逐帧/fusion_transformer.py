import numpy as np

class FusionTransformer:
    def __init__(self, d_model=32, nhead=4, num_layers=2, dropout=0.1):
        self.available = False
        self.torch = None
        try:
            import torch
            import torch.nn as nn
            self.torch = torch
            self.nn = nn
            self.available = True
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            self.device = device
            self.embed = nn.Linear(5, d_model)
            self.prior_embed = nn.Linear(3, d_model)
            encoder_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead, batch_first=True, dropout=dropout)
            self.encoder = nn.TransformerEncoder(encoder_layer, num_layers)
            self.head = nn.Linear(d_model, 1)
            self.sigmoid = nn.Sigmoid()
            self.to(device)
        except Exception:
            self.available = False

    def to(self, device):
        if self.available:
            self.embed.to(device)
            self.prior_embed.to(device)
            self.encoder.to(device)
            self.head.to(device)

    def _brightness(self, data):
        from scipy import ndimage
        smoothed = ndimage.gaussian_filter(data, sigma=0.8)
        return (smoothed - smoothed.min()) / (smoothed.max() - smoothed.min() + 1e-8)

    def fuse(self, normalized, gmm_prob, expected_equiv_diameter, extra_prob=None):
        h, w = normalized.shape
        brightness = self._brightness(normalized)
        if extra_prob is not None:
            try:
                gmm_prob = 0.5 * gmm_prob + 0.5 * extra_prob
            except Exception:
                pass
        xs, ys = np.meshgrid(np.arange(w), np.arange(h))
        x_norm = xs / max(w - 1, 1)
        y_norm = ys / max(h - 1, 1)
        feats = np.stack([normalized, brightness, gmm_prob, x_norm, y_norm], axis=-1).reshape(-1, 5)
        if self.available:
            torch = self.torch
            device = self.device
            x = torch.tensor(feats, dtype=torch.float32, device=device).unsqueeze(0)
            e = self.embed(x)
            ed = 0.0 if expected_equiv_diameter is None else float(expected_equiv_diameter)
            prior = torch.tensor([[ed / max(h, w), h / 12.0, w / 8.0]], dtype=torch.float32, device=device)
            p = self.prior_embed(prior).unsqueeze(1)
            src = torch.cat([e, p], dim=1)
            out = self.encoder(src)
            out_cells = out[:, :h*w, :]
            logits = self.head(out_cells).squeeze(-1)
            prob = self.sigmoid(logits).detach().cpu().numpy().reshape(h, w)
            return prob
        fused = 0.5 * gmm_prob + 0.3 * normalized + 0.2 * brightness
        fused = np.clip(fused, 0.0, 1.0)
        return fused