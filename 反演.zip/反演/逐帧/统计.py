import re
import os
import json  # 新增json模块导入
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.fftpack import fft
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from scipy.stats import ttest_rel, shapiro, wilcoxon
from bayes_opt import BayesianOptimization
from sklearn.metrics import mean_absolute_error
import statsmodels.api as sm
import tkinter as tk
from tkinter import filedialog

# 删除旧的全局路径定义（第17-20行）
# 全局配置
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
OPTIMIZATION_CACHE = "optimization_cache.json"
DATA_FOLDER = os.path.join(os.path.dirname(__file__), "data")
RESULT_FOLDER = os.path.join(os.path.dirname(__file__), "output")
if not os.path.exists(RESULT_FOLDER):
    os.makedirs(RESULT_FOLDER)

# 基础函数
def parse_real_size(filename):
    pattern = r'-(\d+\.?\d*)cm大'
    match = re.search(pattern, filename)
    return float(match.group(1)) if match else None

def calculate_equivalent_diameter(area_pixels):
    actual_area = area_pixels / 32.0
    return np.sqrt(actual_area / np.pi)

# 核心处理类
class SignalProcessor:
    def __init__(self, params=None):
        self.params = params or {
            'window_size': 5,
            'freq_threshold': 0.1,
            'n_clusters': 2
        }

    def moving_average(self, data):
        window_size = self.params['window_size']
        ret = np.cumsum(data, axis=0, dtype=float)
        ret[window_size:] = ret[window_size:] - ret[:-window_size]
        return ret[window_size - 1:] / window_size

    def extract_features(self, raw_data):
        smoothed = self.moving_average(raw_data)
        n_samples = smoothed.shape[0]
        fft_data = np.apply_along_axis(fft, 0, smoothed)
        frequencies = np.fft.fftfreq(n_samples)
        freq_mask = np.abs(frequencies) > self.params['freq_threshold']
        return np.abs(fft_data[freq_mask, :])

    def cluster_analysis(self, features):
        scaled = StandardScaler().fit_transform(features.T).T
        X = scaled.reshape(-1, 1)
        model = KMeans(
            n_clusters=self.params['n_clusters'],
            random_state=42
        )
        return model.fit_predict(X).reshape(scaled.shape)

    def process(self, file_path):
        try:
            df = pd.read_csv(file_path)
            mat_data = df[[f'MAT_{i}' for i in range(96)]].values
            time_points = df['SN'].values
            features = self.extract_features(mat_data)
            labels = self.cluster_analysis(features)
            abnormal_area = np.sum(labels == 1, axis=1)
            diameters = calculate_equivalent_diameter(abnormal_area)
            valid_time = time_points[:len(diameters)]
            return diameters, valid_time, abnormal_area
        except Exception as e:
            print(f"处理错误 {file_path}: {str(e)}")
            return None, None, None

# 贝叶斯优化模块
class BayesianOptimizer:
    def __init__(self, data_folder):
        self.data_folder = data_folder
        self.optimization_data = self._preload_data()

    def _preload_data(self):
        data = {}
        for fname in os.listdir(self.data_folder):
            if fname.endswith('.CSV'):
                path = os.path.join(self.data_folder, fname)
                real_size = parse_real_size(fname)
                if real_size is None:
                    continue
                data[fname] = (real_size, pd.read_csv(path))
        return data

    def _objective_function(self, window_size, freq_threshold, n_clusters):
        params = {
            'window_size': int(round(window_size)),
            'freq_threshold': freq_threshold,
            'n_clusters': int(round(n_clusters))
        }
        processor = SignalProcessor(params)
        corrected_values = []
        real_sizes = []
        for fname, (real_size, df) in self.optimization_data.items():
            try:
                mat_data = df[[f'MAT_{i}' for i in range(96)]].values
                features = processor.extract_features(mat_data)
                labels = processor.cluster_analysis(features)
                abnormal_area = np.sum(labels == 1, axis=1)
                diameters = calculate_equivalent_diameter(abnormal_area)
                closest = diameters[np.argmin(np.abs(diameters - real_size))]
                corrected = diameters * (real_size / closest)
                closest_corrected = corrected[np.argmin(np.abs(corrected - real_size))]
                corrected_values.append(closest_corrected)
                real_sizes.append(real_size)
            except:
                continue

        if len(corrected_values) > 0 and len(real_sizes) > 0:
            mae = mean_absolute_error(real_sizes, corrected_values)
            return -mae
        return -np.inf

    def optimize(self, init_points=5, n_iter=15):
        pbounds = {
            'window_size': (3, 10),
            'freq_threshold': (0.05, 0.2),
            'n_clusters': (2, 4)
        }
        optimizer = BayesianOptimization(
            f=self._objective_function,
            pbounds=pbounds,
            random_state=42,
            verbose=2
        )
        optimizer.maximize(init_points=init_points, n_iter=n_iter)
        best = optimizer.max['params']
        best_params = {
            'window_size': int(round(best['window_size'])),
            'freq_threshold': best['freq_threshold'],
            'n_clusters': int(round(best['n_clusters']))
        }
        with open(OPTIMIZATION_CACHE, 'w') as f:
            json.dump(best_params, f)
        return best_params

# 批处理与可视化模块
class BatchProcessor:
    def __init__(self, data_folder):
        self.data_folder = data_folder
        self.file_data = {}
        self.real_sizes = {}

    def _calculate_correction(self):
        closest_values = []
        for fname, (diameters, _, _) in self.file_data.items():
            real_size = self.real_sizes[fname]
            closest = diameters[np.argmin(np.abs(diameters - real_size))]
            closest_values.append(closest)
        calc_avg = np.mean(closest_values)
        real_avg = np.mean(list(self.real_sizes.values()))
        return real_avg / calc_avg

    def _generate_plots(self, correction_factor):
        corrected_avgs = []
        real_sizes = []
        original_avgs = []

        for fname, (diameters, times, _) in self.file_data.items():
            corrected = diameters * correction_factor
            real_size = self.real_sizes[fname]
            closest = corrected[np.argmin(np.abs(corrected - real_size))]
            original_closest = diameters[np.argmin(np.abs(diameters - real_size))]
            corrected_avgs.append(closest)
            real_sizes.append(real_size)
            original_avgs.append(original_closest)

        corrected_avgs = np.array(corrected_avgs)
        real_sizes = np.array(real_sizes)
        original_avgs = np.array(original_avgs)

        mae = mean_absolute_error(real_sizes, corrected_avgs)
        std_dev = np.std(corrected_avgs - real_sizes)
        _, shapiro_p_corrected = shapiro(corrected_avgs)
        _, shapiro_p_real = shapiro(real_sizes)

        if shapiro_p_corrected > 0.05 and shapiro_p_real > 0.05:
            t_stat, t_p = ttest_rel(corrected_avgs, real_sizes)
            test_method = '配对 t 检验'
            test_stat = t_stat
            test_p = t_p
        else:
            w_stat, w_p = wilcoxon(corrected_avgs, real_sizes)
            test_method = 'Wilcoxon 符号秩检验'
            test_stat = w_stat
            test_p = w_p

        # 计算均方根误差（RMSE）
        rmse = np.sqrt(np.mean((corrected_avgs - real_sizes) ** 2))
        # 计算决定系数（R²）
        X = sm.add_constant(corrected_avgs)
        model = sm.OLS(real_sizes, X).fit()
        r2 = model.rsquared

        # Bland - Altman分析
        mean_values = (corrected_avgs + real_sizes) / 2
        diff_values = corrected_avgs - real_sizes
        mean_diff = np.mean(diff_values)
        sd_diff = np.std(diff_values)
        limits_of_agreement = [mean_diff - 1.96 * sd_diff, mean_diff + 1.96 * sd_diff]

        stats = dict(mean_absolute_error=mae,
                     std_deviation=std_dev,
                     shapiro_p_corrected=shapiro_p_corrected,
                     shapiro_p_real=shapiro_p_real,
                     test_method=test_method,
                     test_statistic=test_stat,
                     test_p_value=test_p,
                     rmse=rmse,
                     r2=r2)

        # 修正前后直径与真实尺寸对比图
        plt.figure(figsize=(8, 6))
        plt.plot(original_avgs, label='原始直径', marker='o')
        plt.plot(corrected_avgs, label='修正后直径', marker='s')
        plt.plot(real_sizes, label='真实尺寸', marker='^')
        plt.title('修正前后直径与真实尺寸对比')
        plt.xlabel('文件索引')
        plt.ylabel('直径')
        plt.legend()
        plt.text(0.5, 0.9, "蓝色点代表原始直径，橙色点代表修正后直径，绿色三角代表真实尺寸。\n此图展示各文件中三者的数值变化，可直观对比修正效果。", 
                 transform=plt.gca().transAxes, fontsize=9)
        plt.savefig(os.path.join(RESULT_FOLDER, 'correction_comparison.png'))  # 修改保存路径到结果文件夹
        plt.close()

        # 统计结果柱状图
        plt.figure(figsize=(8, 6))
        stats_labels = ['MAE', 'Std Dev', 'Shapiro P (Corr)', 'Shapiro P (Real)',
                        f'{test_method} Stat', f'{test_method} P', 'RMSE', 'R²']
        stats_values = [mae, std_dev, shapiro_p_corrected, shapiro_p_real,
                        test_stat, test_p, rmse, r2]
        plt.bar(stats_labels, stats_values)
        for i, v in enumerate(stats_values):
            plt.text(i, v, f'{v:.4f}', ha='center')
        plt.title('统计结果')
        plt.xlabel('统计指标')
        plt.ylabel('值')
        plt.xticks(rotation=45)
        plt.text(0.5, 0.9, "MAE：平均绝对误差，衡量修正后直径与真实尺寸平均偏差程度。\n"
                 "Std Dev：标准差，体现修正后直径数据离散程度。\n"
                 "Shapiro P (Corr) 和 Shapiro P (Real)：分别是修正后直径与真实尺寸正态性检验的p值。\n"
                 f"{test_method} Stat 和 {test_method} P：所选统计检验的统计量和p值，判断两者差异是否显著。\n"
                 "RMSE：均方根误差，对较大偏差更敏感，反映平均偏差幅度。\n"
                 "R²：决定系数，越接近1表明修正后直径与真实尺寸线性关系越强，匹配度越好。", 
                 transform=plt.gca().transAxes, fontsize=9)
        plt.savefig(os.path.join(RESULT_FOLDER,'statistical_results.png'))  # 修改保存路径
        plt.close()

        # Bland - Altman图
        plt.figure(figsize=(8, 6))
        plt.scatter(mean_values, diff_values)
        plt.axhline(y=mean_diff, color='r', linestyle='--', label='平均偏差')
        plt.axhline(y=limits_of_agreement[0], color='g', linestyle='--', label='95%一致性界限（下限）')
        plt.axhline(y=limits_of_agreement[1], color='g', linestyle='--', label='95%一致性界限（上限）')
        plt.title('Bland - Altman 分析')
        plt.xlabel('(修正后直径 + 真实尺寸) / 2')
        plt.ylabel('修正后直径 - 真实尺寸')
        plt.legend()
        plt.text(0.5, 0.9, "此图展示修正后直径与真实尺寸的差值和均值关系。\n"
                 "散点为每对数据的均值与差值，红线是平均偏差，绿线是95%一致性界限。\n"
                 "大部分点落在界限内说明偏差在可接受范围，两者一致性较好。", 
                 transform=plt.gca().transAxes, fontsize=9)
        plt.savefig(os.path.join(RESULT_FOLDER, 'bland_altman_analysis.png'))  # 修改保存路径
        plt.close()

        # 实验结果说明
        result_summary = f"""实验结果说明：
1. 从“修正前后直径与真实尺寸对比”图可知，修正后直径相较原始直径更接近真实尺寸，但仍存在一定偏差。
2. 统计指标方面，MAE和RMSE反映出修正后直径与真实尺寸存在平均偏差，R²显示两者线性关系的紧密程度。
3. 正态性检验的p值判断数据是否符合正态分布，进而选择合适的统计检验方法（配对t检验或Wilcoxon符号秩检验）判断两者差异显著性。
4. Bland - Altman图中，若大部分点落在95%一致性界限内，表明修正后直径与真实尺寸的偏差在可接受范围，一致性较好。"""
        with open(os.path.join(RESULT_FOLDER,'result_summary.txt'), 'w', encoding='utf - 8') as f:
            f.write(result_summary)

    def process_all(self, params):
        processor = SignalProcessor(params)
        files = [fname for fname in os.listdir(self.data_folder) if fname.endswith('.CSV')]
        total_files = len(files)

        results = []
        for i, fname in enumerate(files):
            print(f"Processing file {i + 1}/{total_files}: {fname}")
            path = os.path.join(self.data_folder, fname)
            real_size = parse_real_size(fname)
            if real_size is None:
                continue

            diameters, times, areas = processor.process(path)
            if diameters is not None:
                self.file_data[fname] = (diameters, times, areas)
                self.real_sizes[fname] = real_size
                results.append({
                    'filename': fname,
                    'real_size': real_size,
                    'original_diameter': diameters[np.argmin(np.abs(diameters - real_size))],
                    'times': times.tolist() if times is not None else None,
                    'abnormal_areas': areas.tolist() if areas is not None else None
                })

        correction = self._calculate_correction()

        for result in results:
            diameters = self.file_data[result['filename']][0]
            corrected = diameters * correction
            result['corrected_diameter'] = corrected[np.argmin(np.abs(corrected - result['real_size']))]

        result_df = pd.DataFrame(results)
        result_df.to_csv(os.path.join(RESULT_FOLDER, 'processed_results.csv'), index=False)

        self._generate_plots(correction)

# 将main函数定义上移到文件开头（放在所有类定义之后）
def main(data_folder=None):
    # 创建文件选择对话框
    if not data_folder:
        root = tk.Tk()
        root.withdraw()
        data_folder = filedialog.askdirectory(title="请选择数据文件夹")
        if not data_folder:
            print("未选择文件夹，程序退出")
            return
    
    # 创建结果文件夹
    RESULT_FOLDER = os.path.join(data_folder, "analysis_results")
    if not os.path.exists(RESULT_FOLDER):
        os.makedirs(RESULT_FOLDER)
    
    # 显示文件格式提示
    print("""
    ========================
    文件格式要求：
    1. 数据文件必须为CSV格式
    2. 文件名必须包含尺寸标记（例：-3.5cm大）
    3. 文件应包含96个MAT列（MAT_0到MAT_95）
    4. 必须包含SN时间序列列
    ========================
    """)
    
    # 后续流程保持不变
    if os.path.exists(OPTIMIZATION_CACHE):
        with open(OPTIMIZATION_CACHE, 'r') as f:
            params = json.load(f)
    else:
        optimizer = BayesianOptimizer(data_folder)
        params = optimizer.optimize(init_points=5, n_iter=15)

    processor = BatchProcessor(data_folder)
    processor.process_all(params)

# 删除文件末尾的重复调用（最后两行）
if __name__ == "__main__":
    main()