import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
import os  # 添加此导入
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import numpy as np
from scipy import signal
import matplotlib.pyplot as plt  # 新增导入

from 察结 import create_stress_evolution_animation

class StressVisualizationApp:
    def __init__(self, root):
        self.root = root
        self.root.title("应力分布可视化工具")
        self.root.geometry("800x600")
        
        self.create_widgets()
        self.df = None
        
    def create_widgets(self):
        # 文件选择区域
        file_frame = ttk.LabelFrame(self.root, text="数据文件")
        file_frame.pack(pady=10, padx=10, fill="x")
        
        ttk.Button(file_frame, text="选择CSV文件", command=self.load_file).pack(side="left", padx=5)
        self.file_label = ttk.Label(file_frame, text="未选择文件")
        self.file_label.pack(side="left", padx=5)
        
        # 参数设置区域
        param_frame = ttk.LabelFrame(self.root, text="动画参数")
        param_frame.pack(pady=10, padx=10, fill="x")
        
        # 在参数设置区域添加以下内容
        ttk.Label(param_frame, text="应力动画帧数:").grid(row=0, column=0, padx=5)
        self.stress_frame_entry = ttk.Entry(param_frame)
        self.stress_frame_entry.insert(0, "50")
        self.stress_frame_entry.grid(row=0, column=1, padx=5)
        
        ttk.Label(param_frame, text="结节动画帧数:").grid(row=1, column=0, padx=5)
        self.nodule_frame_entry = ttk.Entry(param_frame)
        self.nodule_frame_entry.insert(0, "30")
        self.nodule_frame_entry.grid(row=1, column=1, padx=5)
        
        ttk.Label(param_frame, text="统计采样点数:").grid(row=2, column=0, padx=5)
        self.stat_frame_entry = ttk.Entry(param_frame)
        self.stat_frame_entry.insert(0, "1000")
        self.stat_frame_entry.grid(row=2, column=1, padx=5)
        
        # 可视化按钮
        ttk.Button(self.root, text="生成动画", command=self.generate_animation).pack(pady=10)
        
        # 预览区域
        preview_frame = ttk.LabelFrame(self.root, text="数据预览")
        preview_frame.pack(pady=10, padx=10, fill="both", expand=True)
        
        self.figure = Figure(figsize=(6, 4), dpi=100)
        self.canvas = FigureCanvasTkAgg(self.figure, master=preview_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)
        
        # 添加功能选择区域
        self.create_function_selector()
        
        # 增强结果显示区域
        self.create_result_tabs()

    def create_function_selector(self):
        func_frame = ttk.LabelFrame(self.root, text="生成功能选择")
        func_frame.pack(pady=10, fill="x")
    
        # 第一行生成按钮
        gen_style = {'width':18, 'padding':5}
        ttk.Button(func_frame, text="生成应力动画", command=self.generate_stress_animation, **gen_style).pack(side="left", padx=3)
        ttk.Button(func_frame, text="生成结节动画", command=self.generate_nodule_animation, **gen_style).pack(side="left", padx=3)
        
        # 第二行生成按钮
        ttk.Button(func_frame, text="生成统计报告", command=self.generate_statistics_report, **gen_style).pack(side="left", padx=3)
        ttk.Button(func_frame, text="生成修正图表", command=self.generate_correction_plot, **gen_style).pack(side="left", padx=3)
    
        # 第三行按钮（修复样式变量名）
        ttk.Button(func_frame, text="等效直径分析", command=self.run_diameter_analysis, **gen_style).pack(side="left", padx=5)
        ttk.Button(func_frame, text="高频特征分析", command=self.run_frequency_analysis, **gen_style).pack(side="left", padx=5)

    def create_result_tabs(self):
        # 创建带工具栏的标签页
        self.notebook = ttk.Notebook(self.root)
        
        # 动态分析标签页（整合algorithms.py）
        self.dynamic_tab = ttk.Frame(self.notebook)
        self.dynamic_canvas = FigureCanvasTkAgg(Figure(), self.dynamic_tab)
        self.dynamic_canvas.get_tk_widget().pack(fill="both", expand=True)
        
        # 结节检测标签页（整合algorithms.py的结节检测）
        self.nodule_tab = ttk.Frame(self.notebook)
        self.nodule_canvas = FigureCanvasTkAgg(Figure(), self.nodule_tab)
        self.nodule_canvas.get_tk_widget().pack(fill="both", expand=True)
        
        # 统计图表标签页（整合实验统计.py）
        self.stats_tab = ttk.Frame(self.notebook) 
        self.stats_canvas = FigureCanvasTkAgg(Figure(), self.stats_tab)
        self.stats_canvas.get_tk_widget().pack(fill="both", expand=True)
        
        self.notebook.add(self.dynamic_tab, text="动态分析")
        self.notebook.add(self.nodule_tab, text="结节检测")
        self.notebook.add(self.stats_tab, text="统计图表")
        self.notebook.pack(fill="both", expand=True)
    
    def load_file(self):
        # 修改为多文件选择
        file_paths = filedialog.askopenfilenames(
            filetypes=[("CSV文件", "*.csv")],
            title="选择分析文件"
        )
        
        if file_paths:
            try:
                self.df = pd.concat([pd.read_csv(f) for f in file_paths], ignore_index=True)
                self.file_label.config(text=f"已选择 {len(file_paths)} 个文件")
                self.preview_data()
                
                messagebox.showinfo("成功", "文件加载成功！")
            except Exception as e:
                messagebox.showerror("错误", f"加载文件失败: {str(e)}")
    
    def preview_data(self):
        if self.df is not None:
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            
            # 随机选择几个传感器显示预览
            for i in np.random.choice(range(96), size=5, replace=False):
                col = f'MAT_{i}'
                ax.plot(self.df[col].values[:100], label=col)
            
            ax.set_title("传感器数据预览 (前100个时间点)")
            ax.legend()
            self.canvas.draw()
    
    def generate_animation(self):
        # 添加路径选择
        output_dir = filedialog.askdirectory(title="选择保存目录")
        if not output_dir:
            return
        
        # 调用不同模块生成对应图表
        from algorithms import create_nodule_evolution_gif
        from 实验统计 import batch_process_all_files  # 修复导入
        
        # 生成动态分析图
        create_stress_evolution_animation(
            self.df, 
            os.path.join(output_dir, 'dynamic_analysis.gif')  # 确保os模块已导入
        )
        
        # 生成结节检测图
        create_nodule_evolution_gif(self.df, output_dir)
        
        # 生成统计图表
        batch_process_all_files(self.stats_dir, output_dir)
        if self.df is None:
            messagebox.showwarning("警告", "请先选择数据文件")
            return
            
        try:
            frame_count = int(self.frame_entry.get())
            if frame_count <= 0 or frame_count > 1000:
                raise ValueError("帧数应在1-1000之间")
                
            output_path = filedialog.asksaveasfilename(
                defaultextension=".gif",
                filetypes=[("GIF动画", "*.gif")]
            )
            
            if output_path:
                create_stress_evolution_animation(
                    self.df, 
                    output_path=output_path,
                    frame_count=frame_count
                    # 移除 progress_callback 参数
                )
                messagebox.showinfo("成功", "动画生成完成！")
                
        except Exception as e:
            messagebox.showerror("错误", f"生成动画失败: {str(e)}")

    def show_analysis_result(self, figure, tab_type='analysis'):
        """在指定标签页显示分析图表"""
        target_tab = {
            'analysis': self.analysis_tab,
            'stats': self.stats_tab,
            'planar': self.planar_tab
        }[tab_type]
        
        target_tab.focus_set()
        if tab_type == 'stats':
            self.stats_canvas.figure = figure
            self.stats_canvas.draw()
        elif tab_type == 'planar':
            self.planar_canvas.figure = figure
            self.planar_canvas.draw()
        else:
            self.analysis_canvas.figure = figure
            self.analysis_canvas.draw()

    def run_statistical_analysis(self):
        """执行统计分析（整合实验统计.py）"""
        from 实验统计 import batch_process_all_files
        
        folder_path = filedialog.askdirectory(title="选择数据目录")
        if folder_path:
            batch_process_all_files(folder_path)
            
            # 显示生成的统计图
            fig = plt.figure(figsize=(12, 8))
            img = plt.imread(os.path.join(folder_path, '总体统计分析.png'))
            plt.imshow(img)
            plt.axis('off')
            self.show_analysis_result(fig, 'stats')  # 指定在统计图表标签页显示
    
    def show_3d_analysis(self, ax):
        """3D应力分析可视化"""
        stress_data = self.df[[f'MAT_{i}' for i in range(96)]].mean().values.reshape(12, 8)
        
        x = np.arange(8)
        y = np.arange(12)
        X, Y = np.meshgrid(x, y)
        
        ax.plot_surface(X, Y, stress_data, cmap='viridis')
        ax.set_title("三维应力分布")
        ax.set_xlabel("X轴位置")
        ax.set_ylabel("Y轴位置")

    def run_data_correction(self):
        """执行数据修正分析"""
        if self.df is None:
            messagebox.showwarning("警告", "请先加载数据文件")
            return
        
        from .实验统计 import process_single_file
        equivalent_diameter, time_points, _ = process_single_file(self.get_current_file())
        
        fig = Figure(figsize=(10, 6))
        ax = fig.add_subplot(111)
        ax.plot(time_points, equivalent_diameter)
        ax.set_title("等效直径变化曲线")
        self.show_analysis_result(fig)

    def run_diameter_analysis(self):
        """等效直径分析"""
        from .实验统计 import calculate_equivalent_diameter
        # 添加具体分析逻辑...

    def run_frequency_analysis(self):
        """高频特征分析"""
        from .实验统计 import process_single_file
        # 添加具体分析逻辑...

    def run_stress_analysis(self):
        """执行应力分析（整合察结.py）"""
        if self.df is None:
            messagebox.showwarning("警告", "请先加载数据文件")
            return
        
        fig = Figure(figsize=(10, 6))
        self.show_3d_analysis(fig.add_subplot(111, projection='3d'))
        self.show_analysis_result(fig)
        # 新增平面分布图显示
        planar_fig = Figure(figsize=(8,6))
        planar_ax = planar_fig.add_subplot(111)
        stress_data = self.df[[f'MAT_{i}' for i in range(96)]].mean().values.reshape(12, 8)
        planar_ax.contourf(stress_data, cmap='viridis')
        self.show_analysis_result(planar_fig, 'planar')

    def run_nodule_detection(self):
        """执行结节检测（整合algorithms.py）"""
        if self.df is None:
            messagebox.showwarning("警告", "请先加载数据文件")
            return
        
        # 调用算法模块
        from .algorithms import create_nodule_evolution_gif
        
        output_path = filedialog.asksaveasfilename(
            defaultextension=".gif",
            filetypes=[("GIF动画", "*.gif")]
        )
        
        if output_path:
            create_nodule_evolution_gif(self.df, output_path)
            messagebox.showinfo("完成", "结节检测动画已生成")

    def generate_stress_animation(self):
        if self.df is None:
            messagebox.showwarning("警告", "请先加载数据文件")
            return
        
        try:
            frame_count = int(self.stress_frame_entry.get())
            if frame_count <= 0 or frame_count > 1000:
                raise ValueError("帧数应在1-1000之间")
        except ValueError as e:
            messagebox.showerror("输入错误", str(e))
            return
        
        output_path = filedialog.asksaveasfilename(
            defaultextension=".gif",
            filetypes=[("GIF动画", "*.gif")],
            title="保存应力动画"
        )
        
        if output_path:
            create_stress_evolution_animation(
                self.df, 
                output_path=output_path,
                frame_count=frame_count
                # 移除progress_callback参数
            )
            messagebox.showinfo("完成", f"应力动画已保存至：\n{output_path}")

    def generate_nodule_animation(self):
        """生成结节检测动画""" 
        if self.df is None:
            messagebox.showwarning("警告", "请先加载数据文件")
            return
        
        output_path = filedialog.asksaveasfilename(
            defaultextension=".gif",
            filetypes=[("GIF动画", "*.gif")],
            title="保存结节动画"
        )
        if output_path:
            from algorithms import create_nodule_evolution_gif  # 修改为绝对导入
            create_nodule_evolution_gif(self.df, output_path)
            messagebox.showinfo("完成", f"结节动画已保存至：\n{output_path}")

    def generate_statistics_report(self):
        """生成统计报告"""
        file_path = filedialog.askopenfilename(
            filetypes=[("CSV文件", "*.csv")],
            title="选择分析文件"
        )
        
        if file_path:
            from 实验统计 import process_single_file  # 修改为绝对导入
            output_path = filedialog.asksaveasfilename(
                defaultextension=".png",
                filetypes=[("PNG图片", "*.png"), ("PDF文档", "*.pdf")],
                title="保存统计报告"
            )
            
            if output_path:
                # 调用单文件处理函数
                equivalent_diameter, time_points, stats_df = process_single_file(file_path)
                
                # 生成统计图表
                fig = Figure(figsize=(12, 8))
                ax = fig.add_subplot(111)
                stats_df.plot(kind='bar', ax=ax)
                ax.set_title("单文件统计分析")
                
                # 保存并显示结果
                fig.savefig(output_path)
                self.show_analysis_result(fig, 'stats')
                messagebox.showinfo("完成", f"统计报告已保存至：\n{output_path}")

    def generate_correction_plot(self):
        """生成修正图表"""
        output_path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG图片", "*.png")],
            title="保存修正图表"
        )
        if output_path:
            # 调用实验统计中的修正分析
            from .实验统计 import process_single_file
            # ... 生成并保存图表代码 ...

if __name__ == "__main__":
    root = tk.Tk()
    app = StressVisualizationApp(root)
    root.mainloop()