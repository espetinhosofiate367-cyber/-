

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
from sklearn.preprocessing import MinMaxScaler
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation
import io
from PIL import Image
from tqdm import tqdm
from matplotlib.colors import LinearSegmentedColormap
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# 加载数据
def load_data(file_path):
    """加载数据并进行基本检查"""
    df = pd.read_csv(file_path)
    print(f"数据形状: {df.shape}")
    print(f"时间戳数量: {len(df)}")
    return df

# 筛选有效数据
def filter_data(df):
    """
    筛选出包含传感器数据的列,并去除全为0的行。
    :param df: 原始数据框
    :return: 筛选后的数据框
    """
    mat_columns = [f'MAT_{i}' for i in range(96)]
    return df[(df[mat_columns] != 0).any(axis=1)]

# 计算动刚度
def calculate_dynamic_stiffness(df):
    """
    计算每个传感器位置的动刚度（通过频率平均值估算）。
    :param df: 筛选后的数据框
    :return: 每个传感器位置的动刚度值
    """
    def mean_frequency(x):
        f, Pxx_den = signal.periodogram(x, fs=1.0)
        return np.average(f, weights=Pxx_den)
    mat_columns = [f'MAT_{i}' for i in range(96)]
    return df[mat_columns].apply(mean_frequency, axis=0)

# 归一化动刚度
def normalize_dynamic_stiffness(dynamic_stiffness):
    """
    对动刚度数据进行归一化处理。
    :param dynamic_stiffness: 动刚度数据
    :return: 归一化后的动刚度数据
    """
    scaler = MinMaxScaler()
    return scaler.fit_transform(dynamic_stiffness.values.reshape(-1, 1))

# 寻找有明显差异的空间位置
def find_significant_positions(normalized_stiffness, threshold=0.1):
    """
    寻找动刚度有明显差异的空间位置索引。
    :param normalized_stiffness: 归一化后的动刚度数据
    :param threshold: 判断差异明显的阈值
    :return: 有明显差异的空间位置索引
    """
    diff = np.abs(np.diff(normalized_stiffness.flatten()))
    return np.where(diff > threshold)[0]

# 绘制应力变化频率图
def plot_stress_frequency(df):
    """
    绘制每个传感器位置对应的应力变化频率图。
    :param df: 原始数据框
    """
    mat_columns = [f'MAT_{i}' for i in range(96)]
    for col in mat_columns:
        f, Pxx_den = signal.periodogram(df[col], fs=1.0)
        plt.semilogy(f, Pxx_den, label=col)

    plt.xlabel('频率 [Hz]')
    plt.xticks(rotation=45)
    plt.ylabel('应力变化频率')
    plt.title('每个点对应的应力变化频率')
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.show()

# 绘制位置 - 动刚度三维图表
def plot_3d_stiffness(normalized_stiffness):
    """
    绘制位置 - 归一化动刚度的三维图表。
    :param normalized_stiffness: 归一化后的动刚度数据
    """
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    x = np.arange(8)
    y = np.arange(12)
    X, Y = np.meshgrid(x, y)
    Z = normalized_stiffness.reshape(12, 8)

    ax.plot_surface(X, Y, Z)
    ax.set_xlabel('X 位置')
    ax.set_ylabel('Y 位置')
    ax.set_zlabel('归一化动刚度')
    ax.set_title('位置 - 归一化动刚度三维图表')
    plt.show()

class StressAnalyzer:
    def __init__(self):
        self.df = None
    
    def load_data(self, file_path):
        self.df = pd.read_csv(file_path)
        # 添加数据有效性检查
        if 'MAT_0' not in self.df.columns:
            raise ValueError("CSV文件格式不正确，缺少MAT_*列")
        return self.df
    
    def create_stress_animation(self, output_path, frame_count=50):
        try:
            # 修正数据访问方式（原代码中使用了未定义的df变量）
            stress_columns = [f'MAT_{i}' for i in range(96)]
            if self.df is None:
                raise ValueError("未加载数据")
            
            data = self.df[stress_columns].values.astype(float)
            
            # 设置基本参数
            plt.style.use('default')
            plt.rcParams.update({'figure.dpi': 300})
            
            images = []
            print("Generating visualization...")
            
            for idx in range(min(frame_count, len(self.df))):
                try:
                    stress_matrix = self.df[stress_columns].iloc[idx].values.astype(float).reshape(12, 8)  # 使用self.df
                    
                    # 创建图形
                    fig = plt.figure(figsize=(18, 10))
                    gs = plt.GridSpec(2, 3, height_ratios=[3, 1])
                    
                    # 2D热图
                    ax1 = fig.add_subplot(gs[0, 0])
                    im1 = ax1.imshow(stress_matrix, 
                                    cmap='viridis',
                                    aspect='equal')
                    ax1.set_title('2D Stress Distribution')
                    plt.colorbar(im1, ax=ax1)
                    
                    # 3D表面图
                    ax2 = fig.add_subplot(gs[0, 1], projection='3d')
                    x = np.arange(8)
                    y = np.arange(12)
                    X, Y = np.meshgrid(x, y)
                    
                    surf = ax2.plot_surface(X, Y, stress_matrix,
                                            cmap='viridis',
                                            linewidth=0)
                    ax2.set_title('3D Surface Plot')
                    
                    # 等高线图
                    ax3 = fig.add_subplot(gs[0, 2])
                    contour = ax3.contourf(X, Y, stress_matrix,
                                            levels=20,
                                            cmap='viridis')
                    ax3.set_title('Contour Map')
                    plt.colorbar(contour, ax=ax3)
                    
                    # 统计信息
                    ax_stats = fig.add_subplot(gs[1, :])
                    ax_stats.axis('off')
                    stats_text = (
                        f'Time Step: {idx}\n'
                        f'Max: {np.max(stress_matrix):.2f}\n'
                        f'Min: {np.min(stress_matrix):.2f}\n'
                        f'Mean: {np.mean(stress_matrix):.2f}\n'
                        f'Std: {np.std(stress_matrix):.2f}'
                    )
                    ax_stats.text(0.5, 0.5, stats_text,
                                    ha='center',
                                    va='center',
                                    bbox=dict(facecolor='white',
                                            alpha=0.8,
                                            edgecolor='gray'))
                    
                    plt.tight_layout()
                    
                    # 保存当前帧
                    buf = io.BytesIO()
                    plt.savefig(buf, format='png')
                    buf.seek(0)
                    images.append(Image.open(buf))
                    plt.close()
                    
                except Exception as e:
                    print(f"Error at time step {idx}: {str(e)}")
                    continue
            
            if images:
                print("Saving animation...")
                images[0].save(
                    output_path,
                    save_all=True,
                    append_images=images[1:],
                    duration=300,
                    loop=0
                )
                print("Complete!")
            else:
                print("No valid frames generated")
                
        except Exception as e:
            print(f"Processing error: {str(e)}")
            import traceback
            print(traceback.format_exc())  # 添加堆栈跟踪
            raise  # 将异常传递给调用方



# 修改后的主界面类
class StressVisualizationApp:
    def __init__(self, root):
        self.root = root
        self.root.title("应力分布可视化工具 v1.0")
        self.root.geometry("1000x700")
        
        self.create_widgets()
        self.df = None
        
    def create_widgets(self):
        # 文件选择区域
        file_frame = ttk.LabelFrame(self.root, text="数据文件")
        file_frame.pack(pady=10, padx=10, fill="x")
        
        ttk.Button(file_frame, text="选择文件", command=self.load_file).pack(side="left", padx=5)
        self.file_label = ttk.Label(file_frame, text="未选择文件")
        self.file_label.pack(side="left", padx=5)

        # 新增帧数设置区域
        param_frame = ttk.LabelFrame(self.root, text="动画参数")
        param_frame.pack(pady=10, padx=10, fill="x")
        
        ttk.Label(param_frame, text="帧数设置:").pack(side="left", padx=5)
        self.frame_entry = ttk.Entry(param_frame, width=10)
        self.frame_entry.insert(0, "50")  # 默认值
        self.frame_entry.pack(side="left", padx=5)
        
        # 添加执行按钮
        ttk.Button(self.root, text="生成动画", command=self.generate_animation).pack(pady=10)
        
    def load_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV文件", "*.csv")])
        if file_path:
            try:
                self.df = pd.read_csv(file_path)
                self.file_label.config(text=file_path)
                messagebox.showinfo("成功", "文件加载成功！")
            except Exception as e:
                messagebox.showerror("错误", f"加载文件失败: {str(e)}")
                
    def generate_animation(self):
        if self.df is None:
            messagebox.showwarning("警告", "请先选择数据文件")
            return
            
        try:
            # 获取用户输入的帧数
            frame_count = int(self.frame_entry.get() or 50)
            if frame_count <= 0 or frame_count > len(self.df):
                raise ValueError("无效帧数")
                
            output_path = filedialog.asksaveasfilename(
                defaultextension=".gif",
                filetypes=[("GIF动画", "*.gif")]
            )
            
            if output_path:
                # 删除原StressVisualizationApp类
                # 保留create_stress_evolution_animation函数即可
                messagebox.showinfo("成功", "动画生成完成！")
                
        except ValueError as e:
            messagebox.showerror("错误", f"请输入1-{len(self.df)}之间的有效帧数")
        except Exception as e:
            messagebox.showerror("错误", f"生成动画失败: {str(e)}")


# 修改主函数
def main():
    root = tk.Tk()
    app = StressVisualizationApp(root)
    root.mainloop()

if __name__ == '__main__':
    main()
